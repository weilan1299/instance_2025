#!/bin/bash
docker build -t flask-app .